package com.numbertoword.converter;

/**
 * Interface to convert number to words
 */
public interface  IConverter
{
	public  String convert(int number);
}
