package com.numbertoword.service;

/**
 * Interface to convert number to words
 */
public interface INumberToWordService
{
	public String convertToWord(int number);
}
